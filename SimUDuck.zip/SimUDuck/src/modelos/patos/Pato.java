/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos.patos;

/**
 *
 * @author guilhermewolner
 */
public class Pato {
    
    String nomePato;
    
    //Implementação trocada pelo uso do GoF Strategy
//    public void quack(){
//        System.out.println(nomePato+" fez quack!");
//    }
    
    public void nadar(){
        System.out.println(nomePato+" está nadando...");
    }
    
    public void exibir(){
        System.out.println("Imagem do pato "+nomePato);
    }
    
    //Implementação trocada pelo uso do GoF Strategy
//    public void voar(){
//        System.out.println(nomePato+" está voando!");
//    }
    
    
    
    
}

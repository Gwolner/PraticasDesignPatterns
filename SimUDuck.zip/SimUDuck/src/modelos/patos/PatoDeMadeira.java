/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos.patos;

/**
 *
 * @author guilhermewolner
 */
public class PatoDeMadeira extends Pato{
    
    public PatoDeMadeira(){
        super.nomePato = "Pato de madeira";
    }
    
    //Implementação trocada pelo uso do GoF Strategy
//    @Override
//    public void quack(){
//        System.out.println("-Silêncio-");
//    }
}


package simuduck;

import modelos.patos.CabecaVermelha;
import modelos.patos.Mallard;


/**
 *
 * @author guilhermewolner
 */
public class SimUDuck {

    public static void main(String[] args) {
        
//        //Forma baseada em herança que leva ao erro
//        Mallard mallard = new Mallard();
//        
//        mallard.exibir();
//        mallard.quack();
//        mallard.nadar();
//        mallard.quack();
//        mallard.voar();
//        
//        CabecaVermelha cv = new CabecaVermelha();
//        cv.exibir();
//        cv.quack();
//        cv.nadar();
//        cv.quack();
//        cv.voar();
    
    
    }
}
